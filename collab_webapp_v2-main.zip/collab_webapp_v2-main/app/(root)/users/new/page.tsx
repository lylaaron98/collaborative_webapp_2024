import React from "react";

const NewUser = () => {
  return <div>NewUser</div>;
};

export default NewUser;
