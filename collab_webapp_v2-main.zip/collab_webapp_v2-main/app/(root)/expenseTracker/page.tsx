import React from "react";
import ExpenseTracker from "@/app/(root)/expenseTracker/ExpenseTracker";

const page = () => {
  return <ExpenseTracker />;
};

export default page;
